﻿namespace Clinic
{
    public  static class Settings
    {
        public static string Secret = "T60iG20ed4jIZfQkWDb7wyGbxpG1QiPH";
    }
}
